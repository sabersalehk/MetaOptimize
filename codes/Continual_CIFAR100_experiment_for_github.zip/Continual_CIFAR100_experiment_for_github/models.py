import torch
import torch.nn as nn

class SimpleCNN(nn.Module):
    def __init__(self, num_classes=10):
        super(SimpleCNN, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 16, kernel_size=3, padding=1),  # 16 x 32 x 32
            nn.ReLU(),
            nn.MaxPool2d(2, 2),  # 16 x 16 x 16
            nn.Conv2d(16, 32, kernel_size=3, padding=1),  # 32 x 16 x 16
            nn.ReLU(),
            nn.MaxPool2d(2, 2),  # 32 x 8 x 8
        )
        self.classifier1 = nn.Sequential(
            nn.Flatten(),
            nn.Linear(32 * 8 * 8, 128),
            nn.ReLU())
        self.classifier2 = nn.Linear(128, num_classes)
        
        
    def forward(self, x):
        x = self.features(x)
        self.probed_layer = self.classifier1(x)
        x = self.classifier2(self.probed_layer)
        return x

