import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
from torch.utils.tensorboard import SummaryWriter
import numpy as np
from torch.utils.data import DataLoader
#from optimizers import get_optimizer
from HF import build_optimizer
from models import get_model
import os
import random
import pickle


model_name = 'SimpleCNN'  # Options: 'LeNet', 'SimpleCNN', 'SmallCNN', 'MLP'
alg_base = 'AdamW'   # Options: 'SGDm', 'AdamW', 'RMSProp', 'Lion'
alg_meta =  'fixed' # Options: 'fixed', 'SGDm' ,'AdamW', 'RMSProp', 'Lion'

stepsize_groups = 'scalar' # Options: 'scalar', 'last_layer_and_others'


meta_stepsize = 1e-3
lr = 0.01
weight_decay_base = 0.0


batch_size = 1
num_epochs_per_task = 1
classes_per_task = 10
seed = 0 # or None

gamma_meta = 1.0
normalizer_param_base = .999
momentum_param_base = .9
Lion_beta2_base = .99
normalizer_param_meta = .999
momentum_param_meta = .9
Lion_beta2_meta = .99


# -----------------------------------------------------------------------------
config_keys = [
    k
    for k, v in globals().items()
    if not k.startswith("_") and isinstance(v, (int, float, bool, str))
]
exec(open("configurator.py").read())  # overrides from command line or config file
config = {k: globals()[k] for k in config_keys}  # will be useful for logging

run_name = f"base_{alg_base}_alpha0_{lr}_wd_{weight_decay_base}___meta_{alg_meta}"
if alg_meta not in ['fixed']:
    run_name += f"_{stepsize_groups}_eta_{meta_stepsize}_gamma_{gamma_meta}"

log_dir_uid=f"____seed_{seed}__{int(1000*np.random.uniform())}"
log_dir = os.path.join("tensorboard", f"{model_name}_cpt{classes_per_task}_b{batch_size}", alg_base, run_name+log_dir_uid)

num_tasks = 100//classes_per_task
# ------
if seed is not None:
    #random.seed(seed)
    np.random.seed(seed)
    #torch.manual_seed(seed)

#class_indices = np.arange(100)
class_indices = np.random.permutation(100)

# Custom dataset to handle task-specific data and label mapping
class TaskDataset(torch.utils.data.Dataset):
    def __init__(self, dataset, task_classes):
        self.dataset = dataset
        self.task_classes = task_classes
        self.class_to_idx = {c: idx for idx, c in enumerate(task_classes)}
        # Get indices of samples that belong to the task_classes
        self.indices = [i for i, (_, target) in enumerate(self.dataset) if target in self.task_classes]
        
    def __len__(self):
        return len(self.indices)
    
    def __getitem__(self, idx):
        data_idx = self.indices[idx]
        img, target = self.dataset[data_idx]
        # Map target to 0-9
        target_mapped = self.class_to_idx[target]
        return img, target_mapped

# -----------------------------------------------------------------------------


device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')  # Use GPU if available
# Optionally, shuffle the class indices
# np.random.shuffle(class_indices)
tasks_classes = np.array_split(class_indices, num_tasks)

# Define transformations
transform_train = transforms.Compose([
    transforms.RandomCrop(32, padding=4),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
])

transform_test = transforms.Compose([
    transforms.ToTensor(),
])

# Load the CIFAR-100 dataset
train_dataset = torchvision.datasets.CIFAR100(root='./data', train=True, download=True, transform=transform_train)
test_dataset = torchvision.datasets.CIFAR100(root='./data', train=False, download=True, transform=transform_test)

# Set up TensorBoard writer
writer = SummaryWriter(log_dir)

# Initialize the model with the number of classes for the first task
num_classes = classes_per_task  # 10
model = get_model(model_name, num_classes)
model.to(device)



class args_for_opt:
    def __init__(self):
        return
args = args_for_opt()
args.alg_base=alg_base
args.alg_meta=alg_meta
args.gamma=gamma_meta
args.stepsize_groups=stepsize_groups 
args.alpha0=lr
args.weight_decay_base=weight_decay_base
args.normalizer_param_base=normalizer_param_base
args.momentum_param_base=momentum_param_base
args.Lion_beta2_base=Lion_beta2_base
args.meta_stepsize=meta_stepsize
args.weight_decay_meta=0
args.normalizer_param_meta=normalizer_param_meta
args.momentum_param_meta=momentum_param_meta
args.Lion_beta2_meta=Lion_beta2_meta


# Define optimizer
optimizer = build_optimizer(model, args, writer)
    

# Define loss function
criterion = nn.CrossEntropyLoss()
global_epoch=0
global_iter=0
total_samples_from_beginning=0
total_correct_from_beginning=0.0
# Training loop over tasks
for task_id, task_classes in enumerate(tasks_classes):
    #print(f"Training on Task {task_id+1}/{num_tasks} with classes {task_classes}")
    
    # Create task-specific datasets
    train_task_dataset = TaskDataset(train_dataset, task_classes)
    test_task_dataset = TaskDataset(test_dataset, task_classes)
    
    train_loader = DataLoader(train_task_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_task_dataset, batch_size=batch_size, shuffle=False)
    
    # Reassign the output layer to the current task's number of classes
    if False:
        num_classes = len(task_classes)
        # Update the model's output layer
        if model_name == 'MLP':
            model.model[-1] = nn.Linear(model.model[-2].out_features, num_classes)
            model.model[-1].to(device)
        else:
            model.classifier[-1] = nn.Linear(model.classifier[-1].in_features, num_classes)
            model.classifier[-1].to(device)
    
    if False:
        # Re-initialize the output layer's weights
        if hasattr(model, 'classifier'):
            model.classifier[-1].reset_parameters()
        else:
            model.model[-1].reset_parameters()
    
    # Initialize lists to store accuracies for averaging
    train_accuracies = []
    test_accuracies = []
    
    # Training loop for the current task
    for epoch in range(num_epochs_per_task):
        global_epoch+=1
        model.train()
        total_correct = 0
        total_samples = 0
        running_loss = 0.0
        for images, labels in train_loader:
            images, labels = images.to(device), labels.to(device)
            
            model.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            optimizer.step(model, loss)
            
            with torch.no_grad():
                # Compute accuracy
                _, predicted = outputs.max(1)
                total_correct += predicted.eq(labels).sum().item()
                total_correct_from_beginning += predicted.eq(labels).sum().item()
                total_samples += labels.size(0)
                total_samples_from_beginning += labels.size(0)
                running_loss += loss.item()
                global_iter += 1

            if global_iter%200==0:
                train_accuracy_from_beginning = 100.0 * total_correct_from_beginning / total_samples_from_beginning
                writer.add_scalar('Acc_from_beginning/Train_Accuracy', train_accuracy_from_beginning, global_iter)
        
        
        train_accuracy = 100.0 * total_correct / total_samples
        train_loss = running_loss / len(train_loader)
        train_accuracies.append(train_accuracy)

        writer.add_scalar('Acc_epoch/Train_Accuracy', train_accuracy, global_epoch)
        writer.add_scalar('Acc_epoch/Train_Loss', train_loss, global_epoch)
        
        # Test the model on the current task's test set
        model.eval()
        total_correct = 0
        total_samples = 0
        with torch.no_grad():
            for images, labels in test_loader:
                images, labels = images.to(device), labels.to(device)
                outputs = model(images)
                _, predicted = outputs.max(1)
                total_correct += predicted.eq(labels).sum().item()
                total_samples += labels.size(0)
        test_accuracy = 100.0 * total_correct / total_samples
        test_accuracies.append(test_accuracy)
        writer.add_scalar('Acc_epoch/Test_Accuracy', test_accuracy, global_epoch)
        #print(f"Task {task_id+1},\t Epoch {epoch+1}/{num_epochs_per_task},\t Test:{test_accuracy:.2f}%,\t Train:{train_accuracy:.2f}%,\t Loss:{train_loss:.4f}")
    

    writer.add_scalar('Acc_task/Train_Accuracy', train_accuracy, int(task_id)+1)
    writer.add_scalar('Acc_task/Test_Accuracy', test_accuracy, int(task_id)+1)

    print(f"Task {task_id+1},  \t Test:{test_accuracy:.2f}%,\t Train:{train_accuracy:.2f}%")
    
    # early termination
    if task_id+1==2 and train_accuracy<200/classes_per_task:
        break

    # After training on the last task, report the metrics
    if task_id == num_tasks - 1:
        avg_train_accuracy = np.mean(train_accuracies)
        avg_test_accuracy = np.mean(test_accuracies)
        #print(f"Task {task_id+1},\t Epoch {epoch+1}/{num_epochs_per_task},\t Test_last:{test_accuracy:.2f}%,\t Train_last:{train_accuracy:.2f}%,\t Train_avg:{avg_train_accuracy:.2f}%")
        print(f"Final Average Test Accuracy on Task {task_id+1}: {avg_test_accuracy:.2f}%")

train_accuracy_from_beginning = 100.0 * total_correct_from_beginning / total_samples_from_beginning
writer.add_scalar('Acc_from_beginning/Train_Accuracy', train_accuracy_from_beginning, global_iter)
        
# Close the TensorBoard writer
writer.close()


# write data on file
def dump_data(file_name, data):
    if os.path.exists(file_name):
        with open(file_name, 'rb') as file:
            A = pickle.load(file)
        A.append(data)
    else:
        A = [data]
    with open(file_name, 'wb') as file:
        pickle.dump(A, file)

dump_dir = os.path.join("results", f"{model_name}_cpt{classes_per_task}_b{batch_size}")
os.makedirs(dump_dir, exist_ok=True)
dump_data(file_name=os.path.join(dump_dir, run_name), data=train_accuracy_from_beginning)
