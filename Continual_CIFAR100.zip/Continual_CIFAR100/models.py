import torch
import torch.nn as nn

# Define simple network architectures
class SimpleCNN(nn.Module):
    def __init__(self, num_classes=10):
        super(SimpleCNN, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 16, kernel_size=3, padding=1),  # 16 x 32 x 32
            nn.ReLU(),
            nn.MaxPool2d(2, 2),  # 16 x 16 x 16
            nn.Conv2d(16, 32, kernel_size=3, padding=1),  # 32 x 16 x 16
            nn.ReLU(),
            nn.MaxPool2d(2, 2),  # 32 x 8 x 8
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(32 * 8 * 8, 128),
            nn.ReLU(),
            nn.Linear(128, num_classes),
        )
        
    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x
